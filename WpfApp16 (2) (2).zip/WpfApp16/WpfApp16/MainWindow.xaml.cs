﻿using System.Media;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp16.View;
using System.Media;

namespace WpfApp16
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BMI_Click(object sender, RoutedEventArgs e)
        {
            BMIWindow bmiWindow     = new BMIWindow();
            bmiWindow.Show();
            this.Close();


        }

        private void Calorie_Click(object sender, RoutedEventArgs e)
        {
            CalorieCalculator calorie = new CalorieCalculator();
            calorie.Show();
            this.Close();

        }

    }
}