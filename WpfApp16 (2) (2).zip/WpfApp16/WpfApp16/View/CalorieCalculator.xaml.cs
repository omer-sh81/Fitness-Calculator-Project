﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;

namespace WpfApp16.View
{
    /// <summary>
    /// Interaction logic for CalorieCalculator.xaml
    /// </summary>
    public partial class CalorieCalculator : Window
    {

        public CalorieCalculator()
        {

            InitializeComponent();

        }
        double ActivityLvl;
        double weight;
        double heightCm;
        string username;
        int age;
        string gender;
        int Add_Minus;


        private void NewUser_Click(object sender, RoutedEventArgs e)
        {
            weight = double.Parse(WeightTextBox.Text);
            heightCm = double.Parse(HeightTextBox.Text);
            age=int.Parse(AgeTextBox.Text);
            ActivityLvl=int.Parse(ActivityTextBox.Text);
            username = UsernameTextBox.Text;
            gender=GenderTextBox.Text;

            DAL.DAL.ExecuteNonQuery($"INSERT INTO UserData (Username, WeightKg, HeightCm, Age , ActivityLvl,Gender) VALUES ('{username}', {weight}, {heightCm},{age},{ActivityLvl},'{gender}')");
        }
        private void Update_Click(object sender, RoutedEventArgs e)
        {
            weight = double.Parse(WeightTextBox.Text);
            heightCm = double.Parse(HeightTextBox.Text);
            username = UsernameTextBox.Text;
            age = int.Parse(AgeTextBox.Text);
            ActivityLvl = int.Parse(ActivityTextBox.Text);
            DAL.DAL.ExecuteNonQuery($"UPDATE UserData SET HeightCm ={heightCm}, WeightKg ={weight}, Age={age}, ActivityLvl={ActivityLvl} , Gender='{gender}' WHERE Username= '{username}'");
        }
        private void Saved_Click(object sender, RoutedEventArgs e)
        {
            username = UsernameTextBox.Text;
            string query = $"SELECT WeightKg, HeightCm,Age,ActivityLvl,Gender FROM UserData WHERE Username = '{username}'";

            DataTable dt = DAL.DAL.GetDataTable(query);

            if (dt.Rows.Count > 0)
            {
                weight = Convert.ToDouble(dt.Rows[0]["WeightKg"]);
                heightCm = Convert.ToDouble(dt.Rows[0]["HeightCm"]);
                age = Convert.ToInt32(dt.Rows[0]["Age"]);
                ActivityLvl = Convert.ToInt32(dt.Rows[0]["ActivityLvl"]);
                gender = Convert.ToString(dt.Rows[0]["Gender"]);
            }

        }
        private void PlusMass_Click(object sender, RoutedEventArgs e)
        {
            Add_Minus = 0;
            Add_Minus += 1;
        }
        private void MinusMass_Click(object sender, RoutedEventArgs e)
        {
            Add_Minus = 0;
            Add_Minus -= 1;
        }
        private void calculate(object sender, RoutedEventArgs e)
        {

            double Activitylvl = 0;
            double BMR = 0;
            if (ActivityLvl == 1)
            {
                Activitylvl = 1.2;
            }
            else if (ActivityLvl == 2)
            {
                Activitylvl = 1.375;
            }
            else if (ActivityLvl == 3)
            {
                Activitylvl = 1.55;
            }
            else if (ActivityLvl == 4)
            {
                Activitylvl = 1.725;
            }
            else
            {
                Activitylvl = 1.9;
            }
            if (Add_Minus == -1)
            {
                if (gender == "Male")
                {
                    BMR = 66.47 + (13.75 * weight) + (5.003 * heightCm) - (6.755 * age);
                }
                else
                {
                    BMR = 655.1 + (9.563 * weight) + (1.850 * heightCm) - (4.676 * age);
                }

                MessageBox.Show((BMR * Activitylvl - ((7000 * int.Parse(MassTextBox.Text)) / (28 * int.Parse(TimeTextBox.Text)))).ToString());
            }
            else
            {
                if (gender == "Male")
                {
                    BMR = 66.47 + (13.75 * weight) + (5.003 * heightCm) - (6.755 * age);
                }
                else
                {
                    BMR = 655.1 + (9.563 * weight) + (1.850 * heightCm) - (4.676 * age);
                }

                MessageBox.Show((BMR * Activitylvl + ((7000 * int.Parse(MassTextBox.Text)) / (28 * int.Parse(TimeTextBox.Text)))).ToString());
            }
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow wnd = new MainWindow();
            wnd.Show();
            this.Close();

        }


    }
}
