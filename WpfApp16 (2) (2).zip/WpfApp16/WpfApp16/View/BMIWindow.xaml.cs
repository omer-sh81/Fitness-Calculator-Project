﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp16.View
{
    /// <summary>
    /// Interaction logic for BMIWindow.xaml
    /// </summary>
    public partial class BMIWindow : Window
    {


        public BMIWindow()
        {
            InitializeComponent();

        }
        double weight;
        double heightCm;
        string username;        
        private void NewUser_Click(object sender, RoutedEventArgs e)
        {
            weight = double.Parse(WeightTextBox.Text);
            heightCm = double.Parse(HeightTextBox.Text);
            username = usernameTextbox.Text;
            DAL.DAL.ExecuteNonQuery($"INSERT INTO UserData (Username, WeightKg, HeightCm) VALUES ('{username}', {weight}, {heightCm})");
        }
        private void Update_Click(object sender, RoutedEventArgs e)
        {
            weight = double.Parse(WeightTextBox.Text);
            heightCm = double.Parse(HeightTextBox.Text);
            username = usernameTextbox.Text;
            DAL.DAL.ExecuteNonQuery($"UPDATE UserData SET HeightCm ={heightCm}, WeightKg ={weight} WHERE Username= '{username}'");
        }
        private void Saved_Click(object sender, RoutedEventArgs e)
        {
            username = usernameTextbox.Text;
            string query = $"SELECT WeightKg, HeightCm FROM UserData WHERE Username = '{username}'";

            DataTable dt = DAL.DAL.GetDataTable(query);

            if (dt.Rows.Count > 0)
            {
                 weight = Convert.ToDouble(dt.Rows[0]["WeightKg"]);
                 heightCm = Convert.ToDouble(dt.Rows[0]["HeightCm"]);


                
            }

        }
        private void CalculateAndSaveBMI_Click(object sender, RoutedEventArgs e)
        {
            
            
                
                double heightM = heightCm / 100.0;
                double bmi = Math.Round(weight / (heightM * heightM), 2); // שומר 2 ספרות אחרי הנקודה
                username = usernameTextbox.Text; // בהמשך תקבל מהמשתמש המחובר בפועל
                DateTime now = DateTime.Now;


                DAL.DAL.ExecuteNonQuery($"Insert Into BMIHistory (Username,DateMeasured,BMI) Values ('{username}', #{now}#, {bmi})");
                BMI_display.Text = "Your BMI =" + bmi.ToString();
                if (bmi < 18.5)
                {
                    BMI_display.Foreground = Brushes.DarkRed;
                }
                else if (bmi > 18.5 && bmi < 25)
                {
                    BMI_display.Foreground = Brushes.Green;
                }
                else if (bmi > 25 && bmi < 40)
                {
                    BMI_display.Foreground = Brushes.DarkRed;
                    BMI_display.FontWeight = FontWeights.Bold;
                }
                else
                {
                    BMI_display.Foreground = Brushes.Red;
                    BMI_display.FontWeight = FontWeights.UltraBold;
                }



        }
        private void LoadBMIHistory(string username)
        {
            string query = $"SELECT DateMeasured, BMI FROM BMIHistory WHERE username = '{username}' ORDER BY DateMeasured,BMI";

            DataTable dt = DAL.DAL.GetDataTable(query);

            BmiDataGrid.ItemsSource = dt.DefaultView;
        }
        private void ShowHistory_Click(object sender, RoutedEventArgs e)
        {
            string username = usernameTextbox.Text;
            LoadBMIHistory(username);
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow wnd = new MainWindow();
            wnd.Show();
            this.Close();

        }



    }
}
