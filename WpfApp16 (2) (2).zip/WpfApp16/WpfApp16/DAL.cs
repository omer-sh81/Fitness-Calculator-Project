﻿using System.Data;
using System.Data.OleDb;



namespace DAL

{

    public class DAL

    {

        public static OleDbConnection GetConnection()//פונקציה שיוצרת את החיבור למסד הנתונים

        {

            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Shemer-Home\Documents\FitnessCalculator1.accdb";
            //יוצר מחרוזת חיבור שמכילה את כל המידע שהמחשב צריך על מנת להתחבר למסד נתונים

            return new OleDbConnection(connectionString);// ומחזירה רכיב חיבור על בסיס המחרוזת

        }



        public static OleDbCommand GetCommand(OleDbConnection con, string sqlstr)//מכינה את השאילתה שנשלחת למסד הנתונים

        {

            OleDbCommand cmd = new OleDbCommand();//אובייקט חדש מסוג אואלאי דאטאבייס קומנד  זו בעצם הפקודה שתשלח לאקסס

            cmd.Connection = con;//חיבור למסד הנתונים

            cmd.CommandText = sqlstr;//אז cmd מה בעצם אני רוצה לשאול אותו ואז אני יוכל להשתמש בזה בקוד

            return cmd;//מחזיר את הפקודה שהכנת על מנת להתמש בה בחוץ .




        }



        public static DataTable GetDataTable(string sqlStr)//

        {

            OleDbConnection con = GetConnection();//חיבור לדאטא בייס

            OleDbCommand cmd = GetCommand(con, sqlStr);// יצירת פקודה לשליחה למסד הנתונים



            OleDbDataAdapter adp = new OleDbDataAdapter();//ה-"עצם" הזה הוא כמו "מתרגם" או "מתווך" שיודע איך לקחת את התוצאה של פקודת ה-SQL

            adp.SelectCommand = cmd;// (כאן אנחנו אומרים ל"מתאם" איזו פקודת (הוא צריך להשתמש בה כדי לקבל את הנתונים ממסד הנתונים. אנחנו מחברים את ה"שאלה" שלנו ל"מתרגם".

            DataTable dt = new DataTable();// יצירת טבלה ריקה

            adp.Fill(dt);// ממלא את הטבלה שיצרנו לפני כן



            return dt;//מחזיר את הטבלה המלאה בנתונים

             



        }



        public static void ExecuteNonQuery(string sqlStr)//(פונקציה שמבצעת שינוי בנתונים במסד הנתונים, כמו הוספה, עדכון או מחיקה של נתונים)

        {

            OleDbConnection con = GetConnection();//יוצרת חיבור למסד הנתונים

            con.Open();//פותחת את החיבור

            OleDbCommand cmd = GetCommand(con, sqlStr);//יוצרת פקודה לשליחה למסד הנתונים

            cmd.ExecuteNonQuery();//התפקיד של הפוקנציה הזאת  הוא לבצע פקודות אסקואל שלא מחזירות נתונים ישירות כטבלה של תוצאות

            con.Close();//סוגרת את החיבור למסד הנתונים

        }
        public static DataView GetDataView(string sqlStr)//(פונקציה שמחזירה את הנתונים כ-DataView, שהיא כמו טבלה אבל עם אפשרויות נוספות כמו סינון ומיון)

        {

            return GetDataTable(sqlStr).DefaultView;

        }
        // הפונקציה מחזירה לנו את הטבלה במצב תצוגה 
    }





}

